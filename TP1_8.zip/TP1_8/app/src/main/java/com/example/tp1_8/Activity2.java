package com.example.tp1_8;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Activity2 extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);


        LinearLayout listeTrajets = findViewById(R.id.listeTrajet);

        String depart = getIntent().getStringExtra("villeDepart");
        String arrivee = getIntent().getStringExtra("villeArrivee");

        ((TextView)findViewById(R.id.titreResRecherche)).append(" "+depart+" à "+arrivee);

        ((TextView)findViewById(R.id.trajet1Depart)).append(" "+depart+" Nord");
        ((TextView)findViewById(R.id.trajet1Arrivee)).append(" "+arrivee+" Centre");

        ((TextView)findViewById(R.id.trajet2Depart)).append(" "+depart+" Nord");
        ((TextView)findViewById(R.id.trajet2Arrivee)).append(" "+arrivee+" Nord");

        ((TextView)findViewById(R.id.trajet3Depart)).append(" "+depart+" Centre");
        ((TextView)findViewById(R.id.trajet3Arrivee)).append(" "+arrivee+" Ouest");

        ((TextView)findViewById(R.id.trajet4Depart)).append(" "+depart+" Sud");
        ((TextView)findViewById(R.id.trajet4Arrivee)).append(" "+arrivee+" Centre");
    }
}
