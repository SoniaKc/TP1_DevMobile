package com.example.tp1_9;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Activity2 extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_2);

        EditText date = findViewById(R.id.date);
        String data = getIntent().getStringExtra("date");
        date.setText(data, TextView.BufferType.EDITABLE);

        Button buttonValider = findViewById(R.id.valider);
        buttonValider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(Activity2.this, MainActivity.class);
                EditText titre = findViewById(R.id.titre);
                intent.putExtra("titre",titre.getText().toString());
                intent.putExtra("date",date.getText().toString());
                startActivity(intent);
            }
        });

        Button buttonAnnuler = findViewById(R.id.annuler);
        buttonAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(Activity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
