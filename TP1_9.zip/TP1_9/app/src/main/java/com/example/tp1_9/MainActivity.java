package com.example.tp1_9;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);


        CalendarView calendarView = findViewById(R.id.calendar);
        Calendar calendar = Calendar.getInstance();

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                calendar.set(Calendar.MONTH, month);
                calendar.set(Calendar.YEAR, year);

                calendarView.setDate(calendar.getTimeInMillis());
            }
        });


        Button addButton = (Button) findViewById(R.id.addEventButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(MainActivity.this, Activity2.class);

                SimpleDateFormat dateFormater = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                String selectedDate = dateFormater.format(calendarView.getDate());
                intent.putExtra("date",selectedDate);

                startActivity(intent);
            }
        });


        String titre = getIntent().getStringExtra("titre");
        String date = getIntent().getStringExtra("date");
        if (titre != null || date != null){
            Toast.makeText(this, "Evènement ajouté :\n" + titre + " le " + date, Toast.LENGTH_LONG).show();
        }
    }
}
