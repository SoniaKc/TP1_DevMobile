package com.example.tp1_3;
import android.app.Activity;
import android.os.Bundle;

public class Activity3 extends Activity{
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_act_3);
    }
}
