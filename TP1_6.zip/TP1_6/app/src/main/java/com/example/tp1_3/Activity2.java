package com.example.tp1_3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity2 extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_act_2);

        String data = getIntent().getStringExtra("teNom");
        ((TextView) findViewById(R.id.textAct2)).append('\n'+data+'\n');
        data = getIntent().getStringExtra("tePrenom");
        ((TextView) findViewById(R.id.textAct2)).append(data+'\n');
        data = getIntent().getStringExtra("teAge");
        ((TextView) findViewById(R.id.textAct2)).append(data+'\n');
        data = getIntent().getStringExtra("teComp");
        ((TextView) findViewById(R.id.textAct2)).append(data+'\n');
        data = getIntent().getStringExtra("teTel");
        ((TextView) findViewById(R.id.textAct2)).append(data);

        Button OkButton = (Button) findViewById(R.id.OKButton);
        OkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent intent = new Intent(Activity2.this, Activity3.class);
                intent.setAction("Act2ToAct3");
                startActivity(intent);
            }
        });

        Button BackButton = (Button) findViewById(R.id.backButton);
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
            Intent intent = new Intent(Activity2.this, MainActivity.class);
                intent.setAction("Act2ToMain");
                startActivity(intent);
            }
        });
    }
}
