package com.example.tp1_3_2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    public	void	onCreate(Bundle savedInstanceState)	{
        super.onCreate(savedInstanceState);

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        // NOM
        TextView tvNom = new TextView(this);
        tvNom.setText("Nom :");
        EditText etNom = new EditText(this);

        // PRENOM
        TextView tvPrenom = new TextView(this);
        tvPrenom.setText("Prénom :");
        EditText etPrenom = new EditText(this);

        // AGE
        TextView tvAge = new TextView(this);
        tvAge.setText("Âge :");
        EditText etAge = new EditText(this);

        // DOMAINE DE COMPETENCES
        TextView tvComp = new TextView(this);
        tvComp.setText("Domaine de compétences :");
        EditText etComp = new EditText(this);

        // NUMERO DE TELEPHONE
        TextView tvTel = new TextView(this);
        tvTel.setText("Numéro de téléphone :");
        EditText etTel = new EditText(this);

        // BOUTON VALIDER
        Button submitButton = new Button(this);
        submitButton.setText("Valider");

        linearLayout.addView(tvNom);
        linearLayout.addView(etNom);
        linearLayout.addView(tvPrenom);
        linearLayout.addView(etPrenom);
        linearLayout.addView(tvAge);
        linearLayout.addView(etAge);
        linearLayout.addView(tvComp);
        linearLayout.addView(etComp);
        linearLayout.addView(tvTel);
        linearLayout.addView(etTel);
        linearLayout.addView(submitButton);

        setContentView(linearLayout);
    }
}
