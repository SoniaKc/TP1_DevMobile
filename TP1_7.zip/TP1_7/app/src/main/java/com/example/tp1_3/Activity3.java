package com.example.tp1_3;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.Manifest;


import androidx.core.app.ActivityCompat;

public class Activity3 extends Activity{
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_act_3);

        String tel = getIntent().getStringExtra("tel");
        ((TextView) findViewById(R.id.telephone)).setText(tel);

        Button callButton = (Button) findViewById(R.id.callButton);
        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                // Ça devrait être correct => A TESTER AVEC VRAI TELEPHONE

                Intent intent2 = new Intent(Intent.ACTION_DIAL);
                intent2.setData(Uri.parse("tel:" + tel));
                startActivity(intent2);


            }
        });
    }
}
